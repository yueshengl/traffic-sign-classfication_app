package com.example.app_api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

/**
 * @Author: Dai
 * @Date: 2024/10/20 11:26
 * @Description: UserController
 * @Version: 1.0
 */

@RestController
@RequestMapping("/api/user")
public class UserController {
    @Autowired
    private UserService userService;

    // 注册接口
    @PostMapping("/register")
    public ResponseEntity<String> register(@RequestBody UserDTO userDTO) {
        String result = userService.register(userDTO.getEmail(), userDTO.getPassword());
        // 返回具体的字符串消息
        if (ConstantUtil.REGISTER_SUCCESS.equals(result)) {
            return ResponseEntity.ok(result);  // 注册成功，返回200 OK
        } else {
            return ResponseEntity.badRequest().body(result);  // 邮箱已注册，返回400 Bad Request
        }
    }

    // 登录接口
    @PostMapping("/login")
    public ResponseEntity<String> login(@RequestBody UserDTO userDTO) {
        String result = userService.login(userDTO.getEmail(), userDTO.getPassword());
        // 根据返回的字符串消息，返回不同的HTTP状态码
        if (ConstantUtil.LOGIN_SUCCESS.equals(result)) {
            return ResponseEntity.ok(result);  // 登录成功，返回200 OK
        } else if (ConstantUtil.PASSWORD_ERROR.equals(result)) {
            return ResponseEntity.status(401).body(result);  // 密码错误，返回401 Unauthorized
        } else {
            return ResponseEntity.badRequest().body(result);  // 邮箱未注册，返回400 Bad Request
        }
    }

    // 修改密码接口
    @PostMapping("/updatePassword")
    public ResponseEntity<String> updatePassword(@RequestBody UpdatePasswordDTO updatePasswordDTO) {
        String result = userService.updatePassword(updatePasswordDTO.getEmail(), updatePasswordDTO.getOldPassword(), updatePasswordDTO.getNewPassword());
        // 返回结果
        if (ConstantUtil.PASSWORD_MODIFY_SUCCESS.equals(result)) {
            return ResponseEntity.ok(result); // 密码修改成功，返回200 OK
        } else if (ConstantUtil.PASSWORD_ERROR.equals(result)) {
            return ResponseEntity.status(401).body(result); // 密码错误，返回401 Unauthorized
        } else {
            return ResponseEntity.badRequest().body(result); // 用户未注册，返回400 Bad Request
        }
    }

    // 重置密码接口
    @PostMapping("/resetPassword")
    public ResponseEntity<String> resetPassword(@RequestBody ResetPasswordDTO resetPasswordDTO) {
        String result = userService.resetPassword(resetPasswordDTO.getEmail(),resetPasswordDTO.getNewPassword());
        // 返回结果
        if (ConstantUtil.PASSWORD_RESET_SUCCESS.equals(result)) {
            return ResponseEntity.ok(result); // 密码修改成功，返回200 OK
        }  else {
            return ResponseEntity.badRequest().body(result); // 用户未注册，返回400 Bad Request
        }
    }
}
