package com.example.app_api;

/**
 * @Author: Dai
 * @Date: 2024/10/21 19:50
 * @Description: UpdatePasswordDTO
 * @Version: 1.0
 */
public class UpdatePasswordDTO {
    private String email;
    private String oldPassword;
    private String newPassword;

    // Getters and Setters
    public String getEmail() {
        return email;
    }
    public void setEmail(String email) {
        this.email = email;
    }
    public String getOldPassword() {
        return oldPassword;
    }
    public void setOldPassword(String oldPassword) {
        this.oldPassword = oldPassword;
    }
    public String getNewPassword() {
        return newPassword;
    }
    public void setNewPassword(String newPassword) {
        this.newPassword = newPassword;
    }
}

