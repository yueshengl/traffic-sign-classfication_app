package com.example.app_api;

import org.springframework.data.jpa.repository.JpaRepository;

import java.util.Optional;

/**
 * @Author: Dai
 * @Date: 2024/10/20 11:15
 * @Description: UserRepository
 * @Version: 1.0
 */
public interface UserRepository extends JpaRepository<User, Long> {
    Optional<User> findByEmail(String email);
}
