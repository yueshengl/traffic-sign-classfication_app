package com.example.app_api;


import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configurers.AbstractHttpConfigurer;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.web.SecurityFilterChain;

/**
 * @Author: Dai
 * @Date: 2024/10/20 12:44
 * @Description: SecurityConfig
 * @Version: 1.0
 */


@Configuration
@EnableWebSecurity
public class SecurityConfig {

    @Bean
    public SecurityFilterChain securityFilterChain(HttpSecurity http) throws Exception {
        http.csrf(AbstractHttpConfigurer::disable)  // 禁用CSRF保护
        .authorizeHttpRequests(auth -> auth.requestMatchers("/api/user/register", "/api/user/login","/api/user/updatePassword","/api/user/resetPassword").permitAll()  // 允许匿名访问注册和登录端点
                                .anyRequest().authenticated()  // 其他请求需要认证
        );
        return http.build();
    }
}

