package com.example.app_api;

/**
 * @Author: Dai
 * @Date: 2024/10/20 12:15
 * @Description: ConstantUtil
 * @Version: 1.0
 */
public class ConstantUtil {
    //邮箱已注册
    public static final String EMAIL_REGISTERED = "邮箱已注册";
    //注册成功
    public static final String REGISTER_SUCCESS = "注册成功";
    //邮箱未注册
    public static final String EMAIL_NOT_REGISTERED = "邮箱未注册";
    //密码错误
    public static final String PASSWORD_ERROR = "密码错误";
    //登录成功
    public static final String LOGIN_SUCCESS = "登录成功";
    //密码修改成功
    public static final String PASSWORD_MODIFY_SUCCESS = "密码修改成功";
    //密码重置成功
    public static final String PASSWORD_RESET_SUCCESS = "密码重置成功";

}
