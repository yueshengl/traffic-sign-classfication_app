package com.example.app_api;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.stereotype.Service;

/**
 * @Author: Dai
 * @Date: 2024/10/20 11:17
 * @Description: UserService
 * @Version: 1.0
 */
@Service
public class UserService {

    @Autowired
    private UserRepository userRepository;
    private final BCryptPasswordEncoder passwordEncoder  = new BCryptPasswordEncoder();

    // 注册方法，返回具体的字符串消息
    public String register(String email, String password) {
        if (userRepository.findByEmail(email).isPresent()) {
            return ConstantUtil.EMAIL_REGISTERED;
        }

        String encodedPassword = passwordEncoder.encode(password);
        User newUser = new User();
        newUser.setEmail(email);
        newUser.setPassword(encodedPassword);

        userRepository.save(newUser);
        return ConstantUtil.REGISTER_SUCCESS;
    }

    // 登录方法，返回具体的字符串消息
    public String login(String email, String password) {
        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            return ConstantUtil.EMAIL_NOT_REGISTERED;
        }

        if (passwordEncoder.matches(password, user.getPassword())) {
            return ConstantUtil.LOGIN_SUCCESS;
        } else {
            return ConstantUtil.PASSWORD_ERROR;
        }
    }

    // 修改密码的方法
    public String updatePassword(String email, String oldPassword, String newPassword) {
        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            return ConstantUtil.EMAIL_NOT_REGISTERED; // 用户不存在
        }

        if (!passwordEncoder.matches(oldPassword, user.getPassword())) {
            return ConstantUtil.PASSWORD_ERROR; // 旧密码错误
        }

        // 更新密码
        String encodedNewPassword = passwordEncoder.encode(newPassword);
        user.setPassword(encodedNewPassword);
        userRepository.save(user);

        return ConstantUtil.PASSWORD_MODIFY_SUCCESS; // 密码修改成功
    }


    public String resetPassword(String email, String newPassword) {
        User user = userRepository.findByEmail(email).orElse(null);

        if (user == null) {
            return ConstantUtil.EMAIL_NOT_REGISTERED; // 用户不存在
        }

        // 重置密码
        String encodedNewPassword = passwordEncoder.encode(newPassword);
        user.setPassword(encodedNewPassword);
        userRepository.save(user);

        return ConstantUtil.PASSWORD_RESET_SUCCESS;
    }
}
