package com.example.app_api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AppApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
